﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Score : MonoBehaviour
{
    public static int scorevalue = 0;
    Text score;

    // Use this for initialization
    void Start()
    {
        score = GetComponent<Text>();
        scorevalue = 0;

    }

    void Update()
    {
        score.text = "Coins Collected: " + scorevalue;
    }
    
}
