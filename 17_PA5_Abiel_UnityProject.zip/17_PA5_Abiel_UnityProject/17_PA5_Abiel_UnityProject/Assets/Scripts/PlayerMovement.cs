﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class PlayerMovement : MonoBehaviour
{
    public float speed;
    Rigidbody PlayerRigidbody;
    Score playerscore;
    public static int scorevalue = 0;


    private void Start()
    {
       
        PlayerRigidbody = GetComponent<Rigidbody>();
        playerscore = GetComponent<Score>();
        
    }

    void FixedUpdate()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3(moveHorizontal, 0, moveVertical);
        PlayerRigidbody.AddForce(movement * speed * Time.deltaTime);


    }
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == ("Coin"))
        {
            Score.scorevalue += 1;
  
            
            Destroy(collision.gameObject);
            if (Score.scorevalue >= 4)
            { 
                SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
            }

           
        }
        if (collision.gameObject.tag == "Danger")
        {
            SceneManager.LoadScene("GameLose");

        }
    }
}
